import './assets/main.css'
import { formatPrice } from './filters/formatPrice';
import cardStyle from './directives/cardStyle';
import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'

const app = createApp(App)
// Register Price filter globally
app.config.globalProperties.$filters = {
    formatPrice,
  };
  // Register cardStyle directive globally
  app.directive('card-style', cardStyle);
  app.use(createPinia())
app.use(router)
app.mount('#app')
