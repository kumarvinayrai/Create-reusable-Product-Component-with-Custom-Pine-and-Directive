<template>
  <div class="product-card" v-card-style>
    <p class="txt-product-category">{{ category }}</p>
    <p class="txt-product-title">{{ title }}</p>
    <img :src="image" :alt="title" />
    <p class="txt-bold txt-wrap">Price: {{ price | formatPrice }}</p>
    <p class="txt-wrap">{{ description }}</p>
    <hr>
    <div class="rating">
      <span v-for="n in 5" :key="n" class="star" :class="{'filled': n <= Math.round(rating.rate)}">★</span>
      <label class="txt-count" :class="{'high-rating': isHighRating(rating.rate)}">({{ rating.count }} reviews)</label>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    category: String,
    title: String,
    image: String,
    price: Number,
    description: String,
    rating: Number,
  },
  methods: {
    isHighRating(rate) {
      return rate > 3; // Change this condition as needed
    },
  },
};
</script>

<style scoped>
.product-card {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  border: 0.0625em solid #ccc;
  border-radius: .5rem;
  padding: 1rem;
  text-align: center;
  transition: box-shadow 0.3s;
  max-width: 250px;
  background-color: #fff;
}
.product-card:hover {
  box-shadow: 0 0.25em .5em rgba(0, 0, 0, 0.2);
}
.product-image {
  max-width: 100%;
  height: auto;
  border-radius: 0.25rem;
}
.product-title {
  font-size: 1.25rem;
  margin: 0.5em 0;
}
.product-description {
  font-size: 0.9rem;
  color: #666;
}
.product-price {
  font-size: 1rem;
  font-weight: bold;
}
/* text css*/
.txt-bold{ 
  font-weight: 600;
  }
  .txt-wrap{
    word-wrap: break-word;
  }
  .txt-product-title {
    font-weight: normal;
    padding: 0 0 .5rem;
    line-height: normal;
}
.txt-product-category {
    text-transform: capitalize;
    font-weight: 600;
    text-decoration: underline;
}
/* rating css*/
.rating {
  font-size: 1.2em;
}
.star {
  color: lightgray; /* Default star color */
  margin-right: 0.125rem;
}

.star.filled {
  color: gold; /* Filled star color */
}
.txt-count{
    font-size: 0.8125rem;
    font-weight: 600;
    padding: 0.1875rem 0.625rem;
    background: red;
    color: #fff;
    border-radius: 0.125rem;
}
hr {
    margin: 0.375rem 0;
}
/* Conditional styling for review count */
.high-rating {
  background: green; /* Background color when review count is greater than 3 */
}
</style>
