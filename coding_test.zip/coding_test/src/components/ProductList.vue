<template>
    <div class="product-container">
      <ProductCard
        v-for="product in products"
        :key="product.id"
        :category="product.category"
        :title="product.title"
        :image="product.image"
        :price="product.price"
        :description="product.description"
        :rating="product.rating"
      />
    </div>
  </template>
  <script>
  import ProductCard from './ProductCard.vue';
  
  export default {
    components: {
      ProductCard,
    },
    data() {
      return {
        products: [],
      };
    },
    async mounted() {
      await this.fetchProducts();
    },
    methods: {
      async fetchProducts() {
        const response = await fetch('https://fakestoreapi.com/products');
        this.products = await response.json();
      },
    },
  };
  </script>
  
  <style scoped>
  .product-container {
    display: flex;
    flex-wrap: wrap;
    justify-content:  space-between;
    gap: 1rem;
    padding: 1rem;
  } 
  </style>
  