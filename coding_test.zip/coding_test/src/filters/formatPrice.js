// Custom filters for price
export function formatPrice(value) {
  return `$${value.toFixed(2)}`;
}