<template>
  <div id="app">
    <h1>Product List</h1>
    <ProductList />
  </div>
</template>

<script>
import ProductList  from '@/components/ProductList.vue';

export default {
  components: {
    ProductList
  }
}
</script>

<style>
#app {
  text-align: center;
}
</style>
