<script setup>
import { RouterLink, RouterView } from 'vue-router' 
</script>

<template>
  <header>
   <div class="wrapper"> 

      <nav>
        <RouterLink to="/">Product</RouterLink>
        <RouterLink to="/about">About</RouterLink>
      </nav>
    </div>
  </header>

  <RouterView />
</template>

<style scoped>

</style>
